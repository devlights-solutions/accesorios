<?php /*%%SmartyHeaderCode:42741843656c8b7537ad2d8-55067160%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0837074e98f9be7d310e181978f9db2ca60f27a2' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/themes/default/modules/blockcategories/blockcategories.tpl',
      1 => 1441225008,
      2 => 'file',
    ),
    '3abca8204bb16166ef0f885c449e487cc3432bee' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/themes/default/modules/blockcategories/category-tree-branch.tpl',
      1 => 1441225009,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '42741843656c8b7537ad2d8-55067160',
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_570c06e899ae89_30574617',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_570c06e899ae89_30574617')) {function content_570c06e899ae89_30574617($_smarty_tpl) {?>
<!-- Block categories module -->
<div id="categories_block_left" class="block">
	<p class="title_block">Categorías</p>
	<div class="block_content">
		<ul class="tree dhtml">
									
<li >
	<a href="http://sistemas-aa.com.ar/trabajos/accesorios/esquina/index.php?id_category=3&amp;controller=category&amp;id_lang=1" 		title="">MOV-AAA-0001</a>
	</li>

												
<li >
	<a href="http://sistemas-aa.com.ar/trabajos/accesorios/esquina/index.php?id_category=4&amp;controller=category&amp;id_lang=1" 		title="">55</a>
	</li>

												
<li class="last">
	<a href="http://sistemas-aa.com.ar/trabajos/accesorios/esquina/index.php?id_category=5&amp;controller=category&amp;id_lang=1" 		title="">MOV-AAA-0002</a>
	</li>

							</ul>
		
		<script type="text/javascript">
		// <![CDATA[
			// we hide the tree only if JavaScript is activated
			$('div#categories_block_left ul.dhtml').hide();
		// ]]>
		</script>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>