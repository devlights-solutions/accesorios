<?php

$conexion = mysql_connect('190.228.29.68','santirock','quilombito','claroaccesorios')
or die ("No se puede conectar con el servidor");

$db = mysql_select_db('claroaccesorios')
or die ("no se puede se�alar la BD");

?>


