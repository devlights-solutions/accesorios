<?php /*%%SmartyHeaderCode:193831560756c8b7546a51d9-84472526%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '273b081d37248e4d80dd757a0847b7d686ab576b' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/blockadvertising/blockadvertising.tpl',
      1 => 1441223925,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '193831560756c8b7546a51d9-84472526',
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_57102b289f9dc5_27271769',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57102b289f9dc5_27271769')) {function content_57102b289f9dc5_27271769($_smarty_tpl) {?>
<!-- MODULE Block advertising -->
<div class="advertising_block">
	<a href="http://www.prestashop.com" title="PrestaShop"><img src="http://sistemas-aa.com.ar/trabajos/accesorios/changomasformosa/modules/blockadvertising/advertising.jpg" alt="PrestaShop" title="PrestaShop" width="155"  height="163" /></a>
</div>
<!-- /MODULE Block advertising -->
<?php }} ?>