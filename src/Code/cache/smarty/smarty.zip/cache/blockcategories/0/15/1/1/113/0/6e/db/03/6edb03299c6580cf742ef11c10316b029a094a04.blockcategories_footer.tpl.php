<?php /*%%SmartyHeaderCode:80370820956c8b7569158a2-54116257%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6edb03299c6580cf742ef11c10316b029a094a04' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/themes/default/modules/blockcategories/blockcategories_footer.tpl',
      1 => 1441225009,
      2 => 'file',
    ),
    '3abca8204bb16166ef0f885c449e487cc3432bee' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/themes/default/modules/blockcategories/category-tree-branch.tpl',
      1 => 1441225009,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '80370820956c8b7569158a2-54116257',
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_5714ed3b955317_83657456',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5714ed3b955317_83657456')) {function content_5714ed3b955317_83657456($_smarty_tpl) {?>
<!-- Block categories module -->
<div class="blockcategories_footer">
	<p class="title_block">Categorías</p>
<div class="category_footer" style="width:100%">
	<div class="list">
		<ul class="tree dhtml">
	
									
<li >
	<a href="http://sistemas-aa.com.ar/trabajos/accesorios/laslomitas/index.php?id_category=3&amp;controller=category&amp;id_lang=1" 		title="">MOV-AAA-0001</a>
	</li>

					
													
<li >
	<a href="http://sistemas-aa.com.ar/trabajos/accesorios/laslomitas/index.php?id_category=4&amp;controller=category&amp;id_lang=1" 		title="">55</a>
	</li>

					
													
<li class="last">
	<a href="http://sistemas-aa.com.ar/trabajos/accesorios/laslomitas/index.php?id_category=5&amp;controller=category&amp;id_lang=1" 		title="">MOV-AAA-0002</a>
	</li>

					
								</ul>
	</div>
</div>
<br class="clear"/>
</div>
<!-- /Block categories module -->
<?php }} ?>