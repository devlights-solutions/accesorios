<?php /* Smarty version Smarty-3.1.14, created on 2016-02-25 12:29:47
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/ccpayment/payment.tpl" */ ?>
<?php /*%%SmartyHeaderCode:143905926056cf1deb30c782-53842487%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '12bf2a388d9a2e933103835639c4b166937ba1ac' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/ccpayment/payment.tpl',
      1 => 1441224009,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '143905926056cf1deb30c782-53842487',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'this_path' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56cf1deb3585e6_74214840',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56cf1deb3585e6_74214840')) {function content_56cf1deb3585e6_74214840($_smarty_tpl) {?><p class="payment_module">

	<a href="<?php echo $_smarty_tpl->tpl_vars['this_path']->value;?>
payment.php" title="<?php echo smartyTranslate(array('s'=>'Pay with your Credit or Debit Card','mod'=>'ccpayment'),$_smarty_tpl);?>
">

		<img src="<?php echo $_smarty_tpl->tpl_vars['this_path']->value;?>
/img/cards.png" alt="<?php echo smartyTranslate(array('s'=>'Pay with your Credit or Debit Card','mod'=>'ccpayment'),$_smarty_tpl);?>
" />

		<?php echo smartyTranslate(array('s'=>'Pay with your Credit or Debit Card','mod'=>'ccpayment'),$_smarty_tpl);?>


	</a>

</p><?php }} ?>