<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 15:58:30
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/themes/default/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:128185447256c8b756c0c6f9-19617464%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5c2c61a013ce0fe75128cf71ae891eede1082c0' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/themes/default/index.tpl',
      1 => 1441224116,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '128185447256c8b756c0c6f9-19617464',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'HOOK_HOME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c8b756c63190_48524859',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c8b756c63190_48524859')) {function content_56c8b756c63190_48524859($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['HOOK_HOME']->value;?>

<?php }} ?>