<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 15:58:28
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/blockadvertising/blockadvertising.tpl" */ ?>
<?php /*%%SmartyHeaderCode:193831560756c8b7546a51d9-84472526%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '273b081d37248e4d80dd757a0847b7d686ab576b' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/blockadvertising/blockadvertising.tpl',
      1 => 1441223925,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '193831560756c8b7546a51d9-84472526',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'adv_link' => 0,
    'adv_title' => 0,
    'image' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c8b7546f97d5_58650680',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c8b7546f97d5_58650680')) {function content_56c8b7546f97d5_58650680($_smarty_tpl) {?>

<!-- MODULE Block advertising -->
<div class="advertising_block">
	<a href="<?php echo $_smarty_tpl->tpl_vars['adv_link']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['adv_title']->value;?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['image']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['adv_title']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['adv_title']->value;?>
" width="155"  height="163" /></a>
</div>
<!-- /MODULE Block advertising -->
<?php }} ?>