<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 21:48:39
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/helpers/list/list_action_default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:35947905156c909672991d7-23686498%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c90322bcb3f77f83e8725f09ef6546b09097653' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/helpers/list/list_action_default.tpl',
      1 => 1441225417,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '35947905156c909672991d7-23686498',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'href' => 0,
    'action' => 0,
    'name' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c9096747b648_29665644',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c9096747b648_29665644')) {function content_56c9096747b648_29665644($_smarty_tpl) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['href']->value;?>
" class="default" title="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" <?php if (isset($_smarty_tpl->tpl_vars['name']->value)){?>name="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
"<?php }?>>
	<img src="../img/admin/asterisk.gif" alt="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" />
</a><?php }} ?>