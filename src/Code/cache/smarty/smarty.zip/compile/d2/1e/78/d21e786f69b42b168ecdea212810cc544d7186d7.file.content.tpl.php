<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 16:10:42
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/controllers/shop_group/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:44564153856c8ba321be464-48724661%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd21e786f69b42b168ecdea212810cc544d7186d7' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/controllers/shop_group/content.tpl',
      1 => 1441225401,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '44564153856c8ba321be464-48724661',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c8ba3220eaf8_52803175',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c8ba3220eaf8_52803175')) {function content_56c8ba3220eaf8_52803175($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("controllers/shop/content.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>