<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 16:01:48
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/blocksharefb/blocksharefb.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23832536756c8b81cde6356-96530848%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '206e2e3fa8196207eab635ae70bb0786bd7b1af9' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/blocksharefb/blocksharefb.tpl',
      1 => 1441223973,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23832536756c8b81cde6356-96530848',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'product_link' => 0,
    'product_title' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c8b81ceb83f6_76811945',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c8b81ceb83f6_76811945')) {function content_56c8b81ceb83f6_76811945($_smarty_tpl) {?>

<li id="left_share_fb">
	<a href="http://www.facebook.com/sharer.php?u=<?php echo $_smarty_tpl->tpl_vars['product_link']->value;?>
&amp;t=<?php echo $_smarty_tpl->tpl_vars['product_title']->value;?>
" class="js-new-window"><?php echo smartyTranslate(array('s'=>'Share on Facebook!','mod'=>'blocksharefb'),$_smarty_tpl);?>
</a>
</li><?php }} ?>