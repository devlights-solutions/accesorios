<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 21:48:08
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/helpers/list/list_action_duplicate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:149840093556c90948bbcf36-77151240%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8d6aa7d6b3a33bfa36466aa1766f82ffbba0b26e' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/helpers/list/list_action_duplicate.tpl',
      1 => 1441225417,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '149840093556c90948bbcf36-77151240',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'action' => 0,
    'confirm' => 0,
    'location_ok' => 0,
    'location_ko' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c90948cc5ac0_85583636',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c90948cc5ac0_85583636')) {function content_56c90948cc5ac0_85583636($_smarty_tpl) {?>
<a class="pointer" title="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" onclick="if (confirm('<?php echo $_smarty_tpl->tpl_vars['confirm']->value;?>
')) document.location = '<?php echo $_smarty_tpl->tpl_vars['location_ok']->value;?>
'; else document.location = '<?php echo $_smarty_tpl->tpl_vars['location_ko']->value;?>
';">
	<img src="../img/admin/duplicate.png" alt="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" />
</a><?php }} ?>