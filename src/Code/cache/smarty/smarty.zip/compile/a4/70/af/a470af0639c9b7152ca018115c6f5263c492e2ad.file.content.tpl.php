<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 21:48:09
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:203522504156c909498e89f6-03237103%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a470af0639c9b7152ca018115c6f5263c492e2ad' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/admin1077/themes/default/template/content.tpl',
      1 => 1441224568,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203522504156c909498e89f6-03237103',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c90949903014_21967275',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c90949903014_21967275')) {function content_56c90949903014_21967275($_smarty_tpl) {?>

<?php if (isset($_smarty_tpl->tpl_vars['content']->value)){?>
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php }?>
<?php }} ?>