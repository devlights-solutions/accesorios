<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 18:12:26
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/contado/views/templates/hook/payment.tpl" */ ?>
<?php /*%%SmartyHeaderCode:64289405256c8d6ba07bc93-29872632%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0fcc3e44e908c09dd1cd4c2b3cad6de51d53a126' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/contado/views/templates/hook/payment.tpl',
      1 => 1441225305,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '64289405256c8d6ba07bc93-29872632',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'link' => 0,
    'this_path_cod' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c8d6ba0c1af4_36083366',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c8d6ba0c1af4_36083366')) {function content_56c8d6ba0c1af4_36083366($_smarty_tpl) {?>

<p class="payment_module">
	<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getModuleLink('contado','validation',array(),true), ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo smartyTranslate(array('s'=>'Pago con tarjeta','mod'=>'contado'),$_smarty_tpl);?>
" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['this_path_cod']->value;?>
contado.gif" alt="<?php echo smartyTranslate(array('s'=>'Pago al contado','mod'=>'contado'),$_smarty_tpl);?>
" style="float:left;" />
		<br /><?php echo smartyTranslate(array('s'=>'Pago con tarjeta','mod'=>'contado'),$_smarty_tpl);?>

		
		<br style="clear:both;" />
	</a>
</p><?php }} ?>