<?php /* Smarty version Smarty-3.1.14, created on 2016-02-20 21:43:11
         compiled from "/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/contado/views/templates/hook/confirmation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:72393759056c9081f70c189-56014228%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '24cec45c3239ad4ce9f55b4167b1fa6bf27f3ac3' => 
    array (
      0 => '/www/sistemas-aa.com.ar/htdocs/trabajos/accesorios/modules/contado/views/templates/hook/confirmation.tpl',
      1 => 1441225304,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '72393759056c9081f70c189-56014228',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'shop_name' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_56c9081f7d2886_01607197',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c9081f7d2886_01607197')) {function content_56c9081f7d2886_01607197($_smarty_tpl) {?>

<p><?php echo smartyTranslate(array('s'=>'Your order on %s is complete.','sprintf'=>$_smarty_tpl->tpl_vars['shop_name']->value,'mod'=>'contado'),$_smarty_tpl);?>

	<br /><br />
	<?php echo smartyTranslate(array('s'=>'You have chosen the cash on delivery method.','mod'=>'contado'),$_smarty_tpl);?>

	<br /><br /><span class="bold"><?php echo smartyTranslate(array('s'=>'Your order will be sent very soon.','mod'=>'contado'),$_smarty_tpl);?>
</span>
	<br /><br /><?php echo smartyTranslate(array('s'=>'For any questions or for further information, please contact our','mod'=>'contado'),$_smarty_tpl);?>
 <a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getPageLink('contact-form',true), ENT_QUOTES, 'UTF-8', true);?>
"><?php echo smartyTranslate(array('s'=>'customer support','mod'=>'contado'),$_smarty_tpl);?>
</a>.
</p>
<?php }} ?>